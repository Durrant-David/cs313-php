<?php
$map=array(
    "na"=>"North America",
    "sa"=>"South America",
    "eu"=>"Europe",
    "as"=>"Asia",
    "au"=>"Australia",
    "af"=>"Africa",
    "an"=>"Antarctica");
?>